</html>
<?php
define("DATAB", "include/DB/");

?>
<br>
<div class="content-wrapper">
    <div class="container-fluid col-md-10">
        <div class="card card-danger bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Borç Ekle</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_bekle" method="post">
                <div class="card-body ">
                    <div class="form-group">
                        <label for="odenecek_tutar">Ödenecek Tutar</label>
                        <input type="text" class="form-control" id="odenecek_tutar" name="odenecek_tutar" required>
                    </div>

                    <div class="form-group">
                        <label for="odeme_tarihi">Ödeme Tarihi</label>
                        <input type="date" class="form-control" id="odeme_tarihi" name="odeme_tarihi" required>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-danger"><b>Ekle</b></button>
                </div>
            </form>

        </div>
    </div>

    <div class="container-fluid col-md-10">
        <br><br>
        <div class="card">
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th>Ödeme ID</th>
                            <th>Ödenecek Tutar</th>
                            <th>Ödeme Tarihi</th>
                            <th>Öğrenci ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once(DATAB . "borc_listele.php");

                        foreach ($odemeler as $row) {
                            echo "<tr>";
                            echo "<td>" . $row['odeme_id'] . "</td>";
                            echo "<td>" . $row['odenecek_tutar'] . "</td>";
                            echo "<td>" . $row['odeme_tarihi'] . "</td>";
                            echo "<td>" . $row['ogrenci_id'] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <div class="container-fluid col-md-10">
        <div class="card card-danger bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Borç Sil</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_bsil" method="post">
                <div class="card-body ">
                    <?php include_once(DATAB . "borc_listele.php") ?>
                    <div class="form-group">
                        <label for="odeme_id">Ödeme ID</label>
                        <select class="form-control" id="odeme_id" name="odeme_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php

                            foreach ($odemeler as $odeme_id) {
                                echo "<option value='" . $odeme_id['odeme_id'] . "'>" . $odeme_id['odeme_id'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-danger"><b>Sil</b></button>
                </div>
            </form>

        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_bekle']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "borc_ekle.php" ?>",  // Borç ekleme işlemlerini gerçekleştirecek PHP dosyasının adını buraya ekleyin
                data: formData,
                dataType: 'json', // Sunucudan beklenen veri türü
                success: function (response) {
                    // AJAX isteği başarılıysa burada yapılacak işlemleri ekleyin
                    alert(response.message);

                    // Başarılı olduğunda sayfayı yeniden yükle
                    location.reload();
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);

                    // Hata olduğunda kullanıcıya bilgi ver
                    alert("Borç eklenirken bir hata oluştu!");
                    console.log(response);
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_bsil']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "borc_silme.php" ?>", // Personel silme işlemlerini gerçekleştirecek PHP dosyasının adını buraya ekleyin
                data: formData,
                dataType: 'json', // Sunucudan beklenen veri türü
                success: function (response) {
                    // AJAX isteği başarılıysa burada yapılacak işlemleri ekleyin
                    console.log(response);

                    // Başarılı olduğunda kullanıcıya bilgi ver veya sayfayı yeniden yükle
                    if (response.success) {
                        alert("Borç başarıyla silindi!");
                        location.reload();
                    } else {
                        alert("Borç silinirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);

                    // Hata olduğunda kullanıcıya bilgi ver
                    alert("Borç silinirken bir hata oluştu!");
                }
            });
        });
    });
</script>