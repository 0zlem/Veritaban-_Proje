<?php
define("DATAB", "include/DB/");

?>
<br>
<div class="content-wrapper">
    <div class="container-fluid col-md-10">
        <div class="card card-success bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Oda Ekle</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_yekle" method="post">
                <div class="card-body ">

                    <div class="form-group">
                        <label for="oda_kapasitesi">Oda Kapasitesi</label>
                        <select class="form-control" id="oda_kapasitesi" name="oda_kapasitesi" required>
                            <option value="1">1</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="doluluk_durumu">Doluluk Durumu</label>
                        <select class="form-control" id="doluluk_durumu" name="doluluk_durumu" required>
                            <option value="Boş" selected>Boş</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label for="kat_numarasi">Kat Numarası</label>
                        <select class="form-control" id="kat_numarasi" name="kat_numarasi" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php
                            for ($kat_numarasi = 0; $kat_numarasi <= 5; $kat_numarasi++) {
                                echo "<option value='" . $kat_numarasi . "'>" . $kat_numarasi . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-success"><b>Kaydet</b></button>
                </div>
            </form>

        </div>
    </div>

    <div class="container-fluid col-md-10">
        <br><br>
        <div class="card">
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th>Oda Numarası</th>
                            <th>Doluluk Durumu</th>
                            <th>Kat Numarası</th>
                            <th>Oda Kapasitesi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once(DATAB . "oda_listele.php");

                        foreach ($odalar as $row) {
                            echo "<tr>";
                            echo "<td>" . $row['oda_id'] . "</td>";
                            echo "<td>" . $row['doluluk_durumu'] . "</td>";
                            echo "<td>" . $row['kat_numarasi'] . "</td>";
                            echo "<td>" . $row['oda_kapasitesi'] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_yekle']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "oda_ekle.php" ?>", // Formun gönderileceği PHP dosyasının adını buraya ekleyin
                data: formData,
                success: function (response) {
                    alert("Oda başarıyla eklendi!")
                    location.reload();
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);
                }
            });
        });
    });
</script>