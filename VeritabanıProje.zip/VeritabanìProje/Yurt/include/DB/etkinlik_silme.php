<?php
// Veritabanı bağlantı bilgilerini içe aktar
@define("DATA", "../../data/");
include_once(DATA . "db.php");

// Başlangıçta hata yok olarak kabul edilir
$response = array("success" => false, "message" => "Etkinlik silinirken bir hata oluştu.");

// Eğer POST verisi varsa işlemleri gerçekleştir
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // POST verilerini al
    $etkinlik_id = $_POST["etkinlik_id"];

    // Personel silme işlemlerini gerçekleştir
    $sql = "call SilEtkinlik('$etkinlik_id')";

    if ($conn->query($sql) === TRUE) {
        // Başarılı yanıt gönder
        $response["success"] = true;
        $response["message"] = "Etkinlik başarıyla silindi!";
    } else {
        // Hata yanıtı gönder
        $response["message"] = "Etkinlik silinirken bir hata oluştu: " . $conn->error;
    }
}

// Diziyi JSON formatına çevirerek ekrana yazdır
echo json_encode($response);
?>