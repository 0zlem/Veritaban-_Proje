<?php
// Veritabanı bağlantı bilgilerini içe aktar
@define("DATA", "../../data/");
include_once(DATA . "db.php");

// Başlangıçta hata yok olarak kabul edilir
$response = array("success" => false, "message" => "Borç silinirken bir hata oluştu.");

// Eğer POST verisi varsa işlemleri gerçekleştir
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // POST verilerini al
    $odeme_id = $_POST["odeme_id"];

    // Borcu silme işlemlerini gerçekleştir
    $sql = "call SilBorc('$odeme_id') ";

    if ($conn->query($sql) === TRUE) {
        // Başarılı yanıt gönder
        $response["success"] = true;
        $response["message"] = "Borç başarıyla silindi!";
    } else {
        // Hata yanıtı gönder
        $response["message"] = "Borç silinirken bir hata oluştu: " . $conn->error;
    }
}

// Diziyi JSON formatına çevirerek ekrana yazdır
echo json_encode($response);
?>