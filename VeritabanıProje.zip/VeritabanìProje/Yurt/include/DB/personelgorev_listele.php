<?php
@define("DATA", "../../data/");
include_once(DATA . "db.php");

function getGorev($gorev_id)
{
    global $conn;

    $gorevQuery = "SELECT gorev_adi FROM gorevler WHERE gorev_id = $gorev_id";
    $gorevResult = $conn->query($gorevQuery);

    if ($gorevResult->num_rows > 0) {
        $gorev = $gorevResult->fetch_assoc();
        return $gorev['gorev_adi'];
    } else {
        return "Bilinmeyen Görev";
    }
}


?>