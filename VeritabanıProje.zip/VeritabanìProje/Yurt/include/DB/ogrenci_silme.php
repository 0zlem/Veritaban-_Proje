<?php
// Veritabanı bağlantı bilgilerini içe aktar
@define("DATA", "../../data/");
include_once(DATA . "db.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $ogrenci_id = $_POST["ogrenci_id"];

    $sql = "call SilOgrenci('$ogrenci_id')";

    if ($conn->query($sql) === TRUE) {
        $response["success"] = true;
        $response["message"] = "Öğrenci başarıyla silindi!";
    } else {
        $response["message"] = "Öğrenci silinirken bir hata oluştu: " . $conn->error;
    }
}

echo json_encode($response);
?>