<?php

@define("DATA", "../../data/");
include_once(DATA . "db.php");


// Odalar tablosundan veri çeken sorgu
$sql = "SELECT * FROM ogrenciler";
$ogrenciler = $conn->query($sql);


?>