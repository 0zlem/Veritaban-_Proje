<?php

@define("DATA", "../../data/");
include_once(DATA . "db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // POST verilerini al
    $etkinlik_adi = $_POST["etkinlik_adi"];
    $personel_id = $_POST["personel_id"];
    $etkinlik_tarihi = $_POST["etkinlik_tarihi"];
    $etkinlik_yeri = $_POST["etkinlik_yeri"];

    // SQL sorgusunu hazırla
    $sql = "call EkleEtkinlik('$etkinlik_adi','$personel_id','$etkinlik_tarihi','$etkinlik_yeri')";

    // SQL sorgusunu çalıştır
    if ($conn->query($sql) === TRUE) {
        // Başarıyla eklendiğini belirtmek için bir yanıt oluştur
        $response = array("success" => true, "message" => "Etkinlik başarıyla eklendi.");
        echo json_encode($response);
    } else {
        // Eğer ekleme başarısızsa bir hata mesajı döndür
        $response = array("success" => false, "message" => "Etkinlik eklenirken bir hata oluştu: " . $conn->error);
        echo json_encode($response);
    }
} else {
    // Eğer doğrudan bu sayfaya erişilmeye çalışılıyorsa hata mesajı döndür
    $response = array("success" => false, "message" => "Hatalı istek!");
    echo json_encode($response);
}
?>