<?php
@define("DATA", "../../data/");
include_once(DATA . "db.php");

function getEtkinlik($etkinlik_id)
{
    global $conn;

    // etkinlik_id'nin değerini kontrol et
    if ($etkinlik_id === null) {
        return null;
    }

    $sql = "SELECT etkinlik_adi FROM etkinlikler WHERE etkinlik_id = $etkinlik_id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $etkinlik = $result->fetch_assoc();
        return $etkinlik['etkinlik_adi'];
    } else {
        return null;
    }
}
?>