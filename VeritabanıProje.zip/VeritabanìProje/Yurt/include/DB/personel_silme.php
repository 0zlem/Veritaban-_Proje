<?php
@define("DATA", "../../data/");
include_once(DATA . "db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $personel_id = $_POST["personel_id"];
    $sql = "call SilPersonel('$personel_id')";

    if ($conn->query($sql) === TRUE) {
        $response["success"] = true;
        $response["message"] = "Personel başarıyla silindi!";
    } else {
        $response["message"] = "Personel silinirken bir hata oluştu: " . $conn->error;
    }
}

echo json_encode($response);
?>