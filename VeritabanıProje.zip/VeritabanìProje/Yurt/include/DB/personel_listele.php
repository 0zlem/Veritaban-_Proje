<?php

@define("DATA", "../../data/");
include_once(DATA . "db.php");



$sql = "SELECT * FROM personeller";
$result = $conn->query($sql);


?>