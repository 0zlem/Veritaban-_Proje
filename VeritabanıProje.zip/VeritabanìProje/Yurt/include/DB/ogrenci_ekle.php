<?php
@define("DATA", "../../data/");
include_once(DATA . "db.php");

// Eğer POST verisi varsa işlemleri gerçekleştir
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // POST verilerini al
    $ogrenci_adsoyad = $_POST["ogrenci_adsoyad"];
    $cinsiyet = $_POST["cinsiyet"];
    $dogum_tarihi = $_POST["dogum_tarihi"];
    $ogrenci_tel = $_POST["ogrenci_tel"];
    $oda_id = $_POST["oda_id"];
    $kayit_tarihi = $_POST["kayit_tarihi"];
    $etkinlik_id = $_POST["etkinlik_id"];

    // SQL sorgusunu hazırla
    $sql = "call EkleOgrenci('$ogrenci_adsoyad','$cinsiyet','$dogum_tarihi','$ogrenci_tel','$oda_id','$kayit_tarihi','$etkinlik_id')";

    // SQL sorgusunu çalıştır
    if ($conn->query($sql) === TRUE) {
        // Başarıyla eklendiğini belirtmek için bir yanıt oluştur
        $response = array("success" => true, "message" => "Öğrenci başarıyla eklendi.");
        echo json_encode($response);
    } else {
        // Eğer ekleme başarısızsa bir hata mesajı döndür
        $response = array("success" => false, "message" => "Öğrenci eklenirken bir hata oluştu: " . $conn->error);
        echo json_encode($response);
    }
} else {
    // Eğer doğrudan bu sayfaya erişilmeye çalışılıyorsa hata mesajı döndür
    $response = array("success" => false, "message" => "Hatalı istek!");
    echo json_encode($response);
}
?>