<?php
define("DATAB", "include/DB/");



?>
<br>
<div class="content-wrapper">
    <div class="container-fluid col-md-10">
        <div class="card card-warning bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Personel Ekle</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_pekle" method="post">
                <div class="card-body ">
                    <div class="form-group">
                        <label for="personel_adsoyad">Adı Soyadı</label>
                        <input type="text" class="form-control" id="personel_adsoyad" name="personel_adsoyad" required>
                    </div>

                    <div class="form-group">
                        <label for="personel_tel">Telefon</label>
                        <input type="tel" class="form-control" maxlength="10" id="personel_tel" name="personel_tel"
                            required>
                    </div>


                    <div class="form-group">
                        <label for="gorev_id">Görev</label>
                        <select class="form-control" id="gorev_id" name="gorev_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php
                            include_once(DATAB . "gorev_listele.php");
                            foreach ($result as $gorev) {
                                echo "<option value='" . $gorev['gorev_id'] . "-" . $gorev['gorev_adi'] . "'>" . $gorev['gorev_adi'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="personel_maas">Maaş</label>
                        <input type="text" class="form-control" id="personel_maas" name="personel_maas" required>
                    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-warning"><b>Ekle</b></button>
                </div>
            </form>

        </div>
    </div>

    <div class="container-fluid col-md-10">
        <br><br>
        <div class="card">
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th>Personel Numarası</th>
                            <th>Personel Adı Soyadı</th>
                            <th>Görev</th>
                            <th>Maaş</th>
                            <th>Personel Telefon</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once(DATAB . "personel_listele.php");
                        include_once(DATAB . "personelgorev_listele.php");

                        foreach ($result as $row) {
                            echo "<tr>";
                            echo "<td>" . $row['personel_id'] . "</td>";
                            echo "<td>" . $row['personel_adsoyad'] . "</td>";
                            echo "<td>" . getGorev($row['gorev_id']) . "</td>";
                            echo "<td>" . $row['personel_maas'] . "</td>";
                            echo "<td>" . $row['personel_tel'] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>

                </table>
            </div>

            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <div class="container-fluid col-md-10">
        <div class="card card-warning bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Personel Sil</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_psil" method="post">
                <div class="card-body ">
                    <?php include_once(DATAB . "personel_listele.php") ?>
                    <div class="form-group">
                        <label for="personel_id">Personel Numarası</label>
                        <select class="form-control" id="personel_id" name="personel_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php

                            foreach ($result as $personel_id) {
                                echo "<option value='" . $personel_id['personel_id'] . "'>" . $personel_id['personel_id'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-warning"><b>Sil</b></button>
                </div>
            </form>

        </div>
    </div>

</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_pekle").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            // Form verilerini al
            var personel_adsoyad = $("#personel_adsoyad").val();
            var personel_tel = $("#personel_tel").val();
            var gorev_id = $("#gorev_id").val();
            var personel_maas = $("#personel_maas").val();

            // Form verilerini bir nesne içinde topla
            var formData = {
                'personel_adsoyad': personel_adsoyad,
                'personel_tel': personel_tel,
                'gorev_id': gorev_id,
                'personel_maas': personel_maas,

            };

            // console.log(formData);
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "personel_ekle.php" ?>", // Formun gönderileceği PHP dosyasının adını buraya ekleyin
                data: formData,
                success: function (response) {
                    alert("Personel başarıyla eklendi!")
                    location.reload();
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);
                }
            });
        });
    });

</script>

<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_psil']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "personel_silme.php" ?>", // Personel silme işlemlerini gerçekleştirecek PHP dosyasının adını buraya ekleyin
                data: formData,
                dataType: 'json', // Sunucudan beklenen veri türü
                success: function (response) {
                    console.log(response);
                    if (response.success) {
                        alert("Personel başarıyla silindi!");
                        location.reload();
                    } else {
                        alert("Personel silinirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    alert("Personel silinirken bir hata oluştu!");
                }
            });
        });
    });
</script>