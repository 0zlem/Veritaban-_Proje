<?php
define("DATAB", "include/DB/");

?>
<br>
<div class="content-wrapper">
    <div class="container-fluid col-md-10">
        <div class="card card-primary bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Öğrenci Ekle</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_oekle" method="post">
                <div class="card-body ">
                    <div class="form-group">
                        <label for="ogrenci_adsoyad">Adı Soyadı</label>
                        <input type="text" class="form-control" id="ogrenci_adsoyad" name="ogrenci_adsoyad" required>
                    </div>

                    <div class="form-group">
                        <label for="cinsiyet">Cinsiyet</label>
                        <select class="form-control" id="cinsiyet" name="cinsiyet" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <option value="Erkek">Erkek</option>
                            <option value="Kız">Kız</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="dogum_tarihi">Doğum Tarihi</label>
                        <input type="date" class="form-control" id="dogum_tarihi" name="dogum_tarihi" required>
                    </div>

                    <div class="form-group">
                        <label for="ogrenci_tel">Telefon</label>
                        <input type="tel" class="form-control" maxlength="10" id="ogrenci_tel" name="ogrenci_tel"
                            required>
                    </div>
                    <?php include_once(DATAB . "oda_listele.php") ?>
                    <div class="form-group">
                        <label for="oda_id">Oda Numarası</label>
                        <select class="form-control" id="oda_id" name="oda_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php
                            // Odalar dizisini kullanarak seçenekleri oluşturun
                            foreach ($odalar as $oda) {
                                echo "<option value='" . $oda['oda_id'] . "'>Kat: " . $oda['kat_numarasi'] . "/" . $oda['oda_id'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="kayit_tarihi">Kayıt Tarihi</label>
                        <input type="date" class="form-control" id="kayit_tarihi" name="kayit_tarihi" required>
                    </div>
                    <label for="etkinlik_adi">Etkinlik Adı</label>
                    <select class="form-control" id="etkinlik_id" name="etkinlik_id">
                        <option value="" selected>Seçiniz</option>
                        <?php
                        include_once(DATAB . "etkinlik_listele.php");
                        foreach ($result as $etkinlik) {
                            echo "<option value='" . $etkinlik['etkinlik_id'] . "'>" . $etkinlik['etkinlik_adi'] . "</option>";
                        }
                        ?>
                    </select>
                </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><b>Ekle</b></button>
        </div>
        </form>

    </div>

    <div class="container-fluid col-md-10">
        <br><br>
        <div class="card">
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th>Öğrenci Numarası</th>
                            <th>Cinsiyet</th>
                            <th>Doğum Tarihi</th>
                            <th>Kayıt Tarihi</th>
                            <th>Oda Numarası</th>
                            <th>Öğrenci Adı Soyadı</th>
                            <th>Öğrenci Telefon</th>
                            <th>Etkinlik Adı</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once(DATAB . "ogrenci_listele.php");
                        include_once(DATAB . "get_etkinlik.php");

                        foreach ($ogrenciler as $row) {
                            echo "<tr>";
                            echo "<td>" . $row['ogrenci_id'] . "</td>";
                            echo "<td>" . $row['cinsiyet'] . "</td>";
                            echo "<td>" . $row['dogum_tarihi'] . "</td>";
                            echo "<td>" . $row['kayit_tarihi'] . "</td>";
                            echo "<td>" . $row['oda_id'] . "</td>";
                            echo "<td>" . $row['ogrenci_adsoyad'] . "</td>";
                            echo "<td>" . $row['ogrenci_tel'] . "</td>";
                            echo "<td>" . getEtkinlik($row['etkinlik_id']) . "</td>";

                            echo "</tr>";

                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <div class="container-fluid col-md-10">
        <div class="card card-primary bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Öğrenci Sil</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_osil" method="post">
                <div class="card-body ">
                    <div class="form-group">
                        <label for="ogrenci_id">Öğrenci Numarası</label>
                        <select class="form-control" id="ogrenci_id" name="ogrenci_id">
                            <option value="" selected disabled>Seçiniz</option>
                            <?php
                            include_once(DATAB . "ogrenci_listele.php");
                            // Odalar dizisini kullanarak seçenekleri oluşturun
                            foreach ($ogrenciler as $ogrenci) {
                                echo "<option value='" . $ogrenci['ogrenci_id'] . "'> " . $ogrenci['ogrenci_id'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><b>Sil</b></button>
                </div>
            </form>

        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    $(document).ready(function () {
        $("form[role='form_oekle']").submit(function (event) {
            event.preventDefault();
            var formData = $(this).serialize();
            console.log(formData);
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "ogrenci_ekle.php" ?>",
                data: formData,
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    if (response.success) {
                        alert("Öğrenci başarıyla eklendi!");
                        location.reload();
                    } else {
                        alert("Öğrenci eklenirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    console.log(error);
                    alert("Öğrenci eklenirken bir hata oluştu!");
                }
            });
        });
    });

</script>

<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_osil']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "ogrenci_silme.php" ?>", // Personel silme işlemlerini gerçekleştirecek PHP dosyasının adını buraya ekleyin
                data: formData,
                dataType: 'json', // Sunucudan beklenen veri türü
                success: function (response) {
                    // AJAX isteği başarılıysa burada yapılacak işlemleri ekleyin
                    console.log(response);

                    // Başarılı olduğunda kullanıcıya bilgi ver veya sayfayı yeniden yükle
                    if (response.success) {
                        alert("Öğrenci başarıyla silindi!");
                        location.reload();
                    } else {
                        alert("Öğrenci silinirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);

                    // Hata olduğunda kullanıcıya bilgi ver
                    alert("Öğrenci silinirken bir hata oluştu!");
                }
            });
        });
    });
</script>