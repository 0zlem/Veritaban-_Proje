<?php
define("DATAB", "include/DB/");

?>
<br>
<div class="content-wrapper">
    <div class="container-fluid col-md-10">
        <div class="card card-info bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Etkinlik Ekle</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_eekle" method="post">
                <div class="card-body ">
                    <div class="form-group">
                        <label for="etkinlik_adi">Etkinlik Adı</label>
                        <input type="text" class="form-control" id="etkinlik_adi" name="etkinlik_adi" required>
                    </div>

                    <div class="form-group">
                        <label for="personel_id">Personel Seç</label>
                        <select class="form-control" id="personel_id" name="personel_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php include_once(DATAB . "personel_listele.php") ?>
                            <?php

                            foreach ($result as $personel_id) {
                                echo "<option value='" . $personel_id['personel_id'] . "'>" . $personel_id['personel_adsoyad'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="etkinlik_tarihi">Etkinlik Tarihi</label>
                        <input type="date" class="form-control" id="etkinlik_tarihi" name="etkinlik_tarihi" required>
                    </div>

                    <div class="form-group">
                        <label for="etkinlik_yeri">Etkinlik Yeri</label>
                        <input type="etkinlik_yeri" class="form-control" id="etkinlik_yeri" name="etkinlik_yeri"
                            required>
                    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-info"><b>Kaydet</b></button>
                </div>
            </form>

        </div>
    </div>

    <div class="container-fluid col-md-10">
        <br><br>
        <div class="card">
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th>Etkinlik Numarası</th>
                            <th>Etkinlik Adı</th>
                            <th>Etkinlik Tarihi</th>
                            <th>Etkinlinlik Yeri</th>
                            <th>Personel Numarası</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once(DATAB . "etkinlik_listele.php");

                        foreach ($result as $row) {
                            echo "<tr>";
                            echo "<td>" . $row['etkinlik_id'] . "</td>";
                            echo "<td>" . $row['etkinlik_adi'] . "</td>";
                            echo "<td>" . $row['etkinlik_tarihi'] . "</td>";
                            echo "<td>" . $row['etkinlik_yeri'] . "</td>";
                            echo "<td>" . $row['personel_id'] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <div class="container-fluid col-md-10">
        <div class="card card-info bg-secondary ">
            <div class="card-header">
                <sh3 class="card-title"><b>Etkinlik Sil</b></sh3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form role="form_esil" method="post">
                <div class="card-body ">
                    <?php include_once(DATAB . "etkinlik_listele.php") ?>
                    <div class="form-group">
                        <label for="etkinlik_id">Etkinlik ID</label>
                        <select class="form-control" id="etkinlik_id" name="etkinlik_id" required>
                            <option value="" selected disabled>Seçiniz</option>
                            <?php

                            foreach ($result as $etkinlik_id) {
                                echo "<option value='" . $etkinlik_id['etkinlik_id'] . "'>" . $etkinlik_id['etkinlik_id'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-info"><b>Sil</b></button>
                </div>
            </form>

        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    $(document).ready(function () {
        $("form[role='form_eekle']").submit(function (event) {
            event.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "etkinlik_ekle.php" ?>",
                data: formData,
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    if (response.success) {
                        alert("Etkinlik başarıyla eklendi!");
                        location.reload();
                    } else {
                        alert("Etkinlik eklenirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    console.log(error);
                    alert("Etkinlik eklenirken bir hata oluştu!");
                }
            });
        });
    });
</script>


<script>
    $(document).ready(function () {
        // Form gönderildiğinde
        $("form[role='form_esil']").submit(function (event) {
            // Formun normal submit işlemini durdur
            event.preventDefault();

            // Form verilerini al
            var formData = $(this).serialize();

            // AJAX isteği yap
            $.ajax({
                type: "POST",
                url: "<?= DATAB . "etkinlik_silme.php" ?>",
                data: formData,
                dataType: 'json', // Sunucudan beklenen veri türü
                success: function (response) {
                    // AJAX isteği başarılıysa burada yapılacak işlemleri ekleyin
                    console.log(response);

                    // Başarılı olduğunda kullanıcıya bilgi ver veya sayfayı yeniden yükle
                    if (response.success) {
                        alert("Etkinlik başarıyla silindi!");
                        location.reload();
                    } else {
                        alert("Etkinlik silinirken bir hata oluştu: " + response.message);
                    }
                },
                error: function (error) {
                    // AJAX isteği başarısızsa burada yapılacak işlemleri ekleyin
                    console.log(error);

                    // Hata olduğunda kullanıcıya bilgi ver
                    alert("Etkinlik silinirken bir hata oluştu!");
                }
            });
        });
    });
</script>