<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-dark navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars fa-lg"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="?page=home" class="nav-link"><b>Anasayfa</b></a>
        </li>

    </ul>
</nav>
<!-- /.navbar -->