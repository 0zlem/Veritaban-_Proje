<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->


    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="user.jpg" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><b>Özlem ÇETİNKAYA</b></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

                <li class="nav-item">
                    <a href="?page=ogrenciler" class="nav-link">
                        <i class="nav-icon far fa-circle text-info"></i>
                        <p><b>Öğrenciler</b></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="?page=personeller" class="nav-link">
                        <i class="nav-icon far fa-circle text-info"></i>
                        <p><b>Personeller</b></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="?page=odalar" class="nav-link">
                        <i class="nav-icon far fa-circle text-info"></i>
                        <p><b>Odalar</b></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="?page=etkinlikler" class="nav-link">
                        <i class="nav-icon far fa-circle text-info"></i>
                        <p><b>Etkinlikler</b></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="?page=odemeler" class="nav-link">
                        <i class="nav-icon far fa-circle text-info"></i>
                        <p><b>Ödemeler</b></p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>