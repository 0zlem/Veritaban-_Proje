<?php
// Veritabanı bilgileri
$host = "localhost"; // Veritabanı sunucu adresi
$database = "ogrenci_yurt"; // Kullanılacak veritabanının adı
$username = "root"; // Veritabanı kullanıcı adı
$password = ""; // Veritabanı şifre

// MySQL bağlantısı oluştur
$conn = new mysqli($host, $username, $password, $database);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

?>